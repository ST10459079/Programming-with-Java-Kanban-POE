package account;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class Account {

    static ArrayList<String> developerArray = new ArrayList<>();
    static ArrayList<String> taskNamesArray = new ArrayList<>();
    static ArrayList<String> taskIDsArray = new ArrayList<>();
    static ArrayList<Integer> taskDurationsArray = new ArrayList<>();
    static ArrayList<String> taskStatusArray = new ArrayList<>();

    private static int cancelCount = 0; // Tracks consecutive cancels

    public static void main(String[] args) {

        JOptionPane.showMessageDialog(null, "Welcome to EasyKanban", "EasyKanban", JOptionPane.INFORMATION_MESSAGE);

        // Registration and login process
        String firstName = promptInput("Please Enter First Name:");
        String surname = promptInput("Please Enter Surname:");

        String username = validateInput("Register a Username (max 5 chars, must contain '_'):", Login::checkUsername,
                "Invalid username format. Please try again.");
        String password = validateInput("Register a Password (min 8 chars, include uppercase, number & special character):",
                Login::checkPasswordComplexity, "Invalid password format. Please try again.");

        showMessage("Username and password successfully captured.");

        boolean isLoginSuccessful;
        do {
            String loginUsername = promptInput("Login - Enter Registered  Username:");
            String loginPassword = promptInput("Login - Enter Registered Password:");
            isLoginSuccessful = Login.loginUser(loginUsername, loginPassword, username, password);
            if (!isLoginSuccessful) {
                showError("Invalid username or password. Please try again.");
            }
        } while (!isLoginSuccessful);

        showMessage(Login.returnLoginStatus(isLoginSuccessful, firstName, surname));

        // Main menu
        while (true) {
            String menuOptions = "Choose an option:\n1. Add Tasks\n2. Show Report\n3. Quit";
            String choice = promptInput(menuOptions);

            if (choice == null) handleCancel(); // Handle cancel behavior
            else if (choice.equals("3")) break;

            switch (choice) {
                case "1":
                    addTasks();
                    break;
                case "2":
                    showReportMenu();
                    break;
                default:
                    showError("Invalid option. Please try again.");
            }
        }
    }

    private static String promptInput(String message) {
        String input = JOptionPane.showInputDialog(null, message, "EasyKanban", JOptionPane.QUESTION_MESSAGE);
        if (input == null) handleCancel(); // Handle cancel behavior
        return input != null ? input.trim() : null;
    }

    private static String validateInput(String message, InputValidator validator, String errorMessage) {
        String input;
        do {
            input = promptInput(message);
            if (input == null) return null; // Return null if user cancels
            if (!validator.validate(input)) {
                showError(errorMessage);
            }
        } while (!validator.validate(input));
        return input;
    }

    private static void handleCancel() {
        cancelCount++;
        if (cancelCount >= 2) {
            showMessage("Exiting program. Goodbye!");
            System.exit(0);
        } else {
            showMessage("Cancel detected. Returning to the previous menu.");
        }
    }

    private static void showError(String message) {
        JOptionPane.showMessageDialog(null, message, "Error", JOptionPane.ERROR_MESSAGE);
    }

    private static void showMessage(String message) {
        JOptionPane.showMessageDialog(null, message, "EasyKanban", JOptionPane.INFORMATION_MESSAGE);
    }

    public static void addTasks() {
        cancelCount = 0; // Reset cancel count when entering a new menu

        int numTasks = Integer.parseInt(validateInput("Enter the number of tasks to add:", input -> input.matches("\\d+"),
                "Please enter a valid number."));

        for (int i = 0; i < numTasks; i++) {
            String taskName = validateInput("Please Enter Task Name:", input -> input.length() >= 2,
                    "Task name must be at least 2 characters.");
            String developer = validateInput("Please Enter Developer First  and Last Name :", input -> input.split(" ").length >= 2,
                    "Please enter both first and last names.");

            int duration = Integer.parseInt(validateInput("Enter Task Duration in hours:", input -> input.matches("\\d+"),
                    "Please enter a valid number for duration."));

            String statusOptions = "Choose Task Status:\n1. To Do\n2. Doing\n3. Done";
            String status = validateInput(statusOptions, input -> input.matches("[1-3]"), "Invalid option. Choose 1, 2, or 3.");
            status = status.equals("1") ? "To Do" : status.equals("2") ? "Doing" : "Done";

            String taskID = taskName.substring(0, Math.min(2, taskName.length())).toUpperCase() + ":" + i + ":" +
                    developer.split(" ")[1].substring(0, Math.min(3, developer.split(" ")[1].length())).toUpperCase();

            developerArray.add(developer);
            taskNamesArray.add(taskName);
            taskIDsArray.add(taskID);
            taskDurationsArray.add(duration);
            taskStatusArray.add(status);

            showMessage("Task successfully added.\nTask ID: " + taskID);
        }

        int totalDuration = taskDurationsArray.stream().mapToInt(Integer::intValue).sum();
        showMessage("Total task duration: " + totalDuration + " hours");
    }

    public static void showReportMenu() {
        cancelCount = 0; // Reset cancel count when entering a new menu

        String reportMenu = """
                            Choose a report option:
                            1. Display 'Done' Tasks
                            2. Longest Task Duration
                            3. Search Task by Name
                            4. Search Tasks by Developer
                            5. Delete Task
                            6. Display All Tasks
                            7. Back to Main Menu""";
        while (true) {
            String choice = promptInput(reportMenu);
            if (choice == null) handleCancel(); // Handle cancel behavior
            else if (choice.equals("7")) break;

            switch (choice) {
                case "1" -> displayDoneTasks();
                case "2" -> displayLongestTask();
                case "3" -> searchTaskByName();
                case "4" -> searchTasksByDeveloper();
                case "5" -> deleteTaskByName();
                case "6" -> displayAllTasks();
                default -> showError("Invalid option. Please try again.");
            }
        }
    }

    public static void displayDoneTasks() {
        StringBuilder output = new StringBuilder("Tasks with 'Done' status:\n");
        for (int i = 0; i < taskStatusArray.size(); i++) {
            if ("Done".equalsIgnoreCase(taskStatusArray.get(i))) {
                output.append(printTaskDetails(i)).append("\n");
            }
        }
        showMessage(output.toString());
    }

    public static void displayLongestTask() {
        int maxIndex = 0;
        for (int i = 1; i < taskDurationsArray.size(); i++) {
            if (taskDurationsArray.get(i) > taskDurationsArray.get(maxIndex)) {
                maxIndex = i;
            }
        }
        showMessage("Longest task:\n" + printTaskDetails(maxIndex));
    }

    public static void searchTaskByName() {
        String taskName = promptInput("Enter Task Name to Search:");
        for (int i = 0; i < taskNamesArray.size(); i++) {
            if (taskNamesArray.get(i).equalsIgnoreCase(taskName)) {
                showMessage(printTaskDetails(i));
                return;
            }
        }
        showError("Task not found.");
    }

    public static void searchTasksByDeveloper() {
        String developer = promptInput("Enter Developer Name to Search:");
        StringBuilder output = new StringBuilder("Tasks assigned to ").append(developer).append(":\n");
        for (int i = 0; i < developerArray.size(); i++) {
            if (developerArray.get(i).equalsIgnoreCase(developer)) {
                output.append(printTaskDetails(i)).append("\n");
            }
        }
        if (output.toString().equals("Tasks assigned to " + developer + ":\n")) {
            showError("No tasks found for the developer.");
        } else {
            showMessage(output.toString());
        }
    }

    public static void deleteTaskByName() {
        String taskName = promptInput("Enter Task Name to Delete:");
        for (int i = 0; i < taskNamesArray.size(); i++) {
            if (taskNamesArray.get(i).equalsIgnoreCase(taskName)) {
                developerArray.remove(i);
                taskNamesArray.remove(i);
                taskIDsArray.remove(i);
                taskDurationsArray.remove(i);
                taskStatusArray.remove(i);
                showMessage("Task '" + taskName + "' successfully deleted.");
                return;
            }
        }
        showError("Task not found.");
    }

    public static void displayAllTasks() {
        StringBuilder output = new StringBuilder("All Tasks:\n");
        for (int i = 0; i < taskNamesArray.size(); i++) {
            output.append(printTaskDetails(i)).append("\n");
        }
        showMessage(output.toString());
    }

    private static String printTaskDetails(int index) {
        return "Task ID: " + taskIDsArray.get(index) + "\n"
                + "Developer: " + developerArray.get(index) + "\n"
                + "Task Name: " + taskNamesArray.get(index) + "\n"
                + "Task Status: " + taskStatusArray.get(index) + "\n"
                + "Task Duration: " + taskDurationsArray.get(index) + " hours";
    }
    public static String generateTaskID(String taskName, int taskNumber, String developer) {
        // Format: "TaskName:TaskNumber:Developer"
        return taskName + ":" + taskNumber + ":" + developer;
    }
    

    

    interface InputValidator {
        boolean validate(String input);
    }
}
