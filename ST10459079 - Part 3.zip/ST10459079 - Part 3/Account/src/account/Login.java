package account;

public class Login {

    // Method to validate the username
    public static boolean checkUsername(String username) {
        // Check if the username length is less than or equal to 5 and contains '_'
        return username.length() <= 5 && username.contains("_");
    }

    // Method to validate password complexity
    public static boolean checkPasswordComplexity(String password) {
        boolean hasUppercase = password.matches(".*[A-Z].*");
        boolean hasNumber = password.matches(".*\\d.*");
        boolean hasSpecialChar = password.matches(".*[@#$%^&+=!].*");
        return password.length() >= 8 && hasUppercase && hasNumber && hasSpecialChar;
    }

    // Method to register the user
    public static String registerUser(String username, String password) {
        if (!checkUsername(username)) {
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.";
        } 
        if (!checkPasswordComplexity(password)) {
            return "Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number, and a special character.";
        } 
        return "Username successfully captured\nPassword successfully captured";
    }

    // Method to verify login details
    public static boolean loginUser(String inputUsername, String inputPassword, String storedUsername, String storedPassword) {
        return inputUsername.equals(storedUsername) && inputPassword.equals(storedPassword);
    }

    // Method to return login status with first and last name
    public static String returnLoginStatus(boolean isLoginSuccessful, String firstname, String surname) {
        if (isLoginSuccessful) {
            return "Welcome " + firstname + " " + surname + ", it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again";
        }
    }

    static Object returnLoginStatus(boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
