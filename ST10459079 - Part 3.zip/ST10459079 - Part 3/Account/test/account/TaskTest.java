package account;

import org.junit.Test;
import static org.junit.Assert.*;

public class TaskTest {

    Task task1 = new Task("Login Feature", 1, "Create Login to authenticate users", "Robyn Harrison", 8, "To Do", "AD:1:BYN");
    Task task2 = new Task("Add Task Feature", 2, "Create Add Task feature to add tasks for users", "Mike Smith", 10, "Doing", "CR:0:IKE");

    @Test
    public void testTaskDescriptionLengthSuccess() {
        String description = task1.getTaskDescription();
        assertTrue(description.length() <= 50);
        assertFalse(description.length() > 50);
        assertEquals("Create Login to authenticate users", description);
    }

    @Test
    public void testTaskDescriptionLengthFailure() {
        Task taskFail = new Task("Login Feature", 1, "This is a task description that exceeds fifty characters and should fail.", "Robyn Harrison", 8, "To Do", "AD:1:BYN");
        String description = taskFail.getTaskDescription();
        assertTrue(description.length() > 50);
        assertFalse(description.length() <= 50);
        assertEquals("This is a task description that exceeds fifty characters and should fail.", description);
    }

    @Test
    public void testTaskIDCorrectness() {
        assertEquals("AD:1:BYN", task1.getTaskID());
        assertTrue(task1.getTaskID().equals("AD:1:BYN"));
        assertFalse(task1.getTaskID().equals("CR:0:IKE"));
        assertEquals("CR:0:IKE", task2.getTaskID());
    }

    @Test
    public void testTotalTaskDurationLoop() {
        int[] durations = {10, 12, 55, 11, 1};
        int total = 0;
        for (int duration : durations) {
            total += duration;
        }
        assertEquals(89, total);
        assertTrue(total == 89);
        assertFalse(total != 89);
    }

    @Test
    public void testTotalTaskDurationForTwoTasks() {
        int totalDuration = task1.getTaskDuration() + task2.getTaskDuration();
        assertEquals(18, totalDuration);
        assertTrue(totalDuration == 18);
        assertFalse(totalDuration != 18);
    }
}
