package account;

import static org.junit.Assert.*;
import org.junit.Test;

public class LoginTest {

    @Test
    public void testCheckUsernameValid() {
        assertTrue(Login.checkUsername("user_"));
        assertFalse(Login.checkUsername("invalidusername"));
        assertEquals("Valid username", "Valid username");
    }

    @Test
    public void testCheckUsernameInvalid() {
        assertFalse(Login.checkUsername("invalidusername"));
        assertTrue(Login.checkUsername("user_"));
        assertEquals("Invalid username", "Invalid username");
    }

    @Test
    public void testCheckPasswordComplexityValid() {
        assertTrue(Login.checkPasswordComplexity("P@ssw0rd!"));
        assertFalse(Login.checkPasswordComplexity("password"));
        assertEquals("Password meets complexity requirements", "Password meets complexity requirements");
    }

    @Test
    public void testCheckPasswordComplexityInvalid() {
        assertFalse(Login.checkPasswordComplexity("password"));
        assertTrue(Login.checkPasswordComplexity("P@ssw0rd!"));
        assertEquals("Password does not meet complexity requirements", "Password does not meet complexity requirements");
    }

    @Test
    public void testLoginUserSuccess() {
        assertTrue(Login.loginUser("user_", "P@ssw0rd!", "user_", "P@ssw0rd!"));
        assertFalse(Login.loginUser("user_", "wrongPassword", "user_", "P@ssw0rd!"));
        assertEquals("Login successful", "Login successful");
    }

    @Test
    public void testLoginUserFailure() {
        assertFalse(Login.loginUser("user_", "wrongPassword", "user_", "P@ssw0rd!"));
        assertTrue(Login.loginUser("user_", "P@ssw0rd!", "user_", "P@ssw0rd!"));
        assertEquals("Login failed", "Login failed");
    }

    @Test
    public void testReturnLoginStatusSuccess() {
        String expected = "Welcome John Doe, it is great to see you again.";
        assertEquals(expected, Login.returnLoginStatus(true, "John", "Doe"));
        assertTrue(true);
        assertFalse(false);
    }

    @Test
    public void testReturnLoginStatusFailure() {
        String expected = "Username or password incorrect, please try again";
        assertEquals(expected, Login.returnLoginStatus(false, "John", "Doe"));
        assertTrue(true);
        assertFalse(false);
    }
}