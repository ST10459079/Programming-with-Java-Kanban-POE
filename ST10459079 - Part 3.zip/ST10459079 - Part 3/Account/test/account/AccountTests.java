package account;

import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;

import static org.junit.Assert.*;

public class AccountTests {

    private ArrayList<String> developerArray;
    private ArrayList<String> taskNamesArray;
    private ArrayList<Integer> taskDurationsArray;

    @Before
    public void setUp() {
        // Initialize arrays before each test
        developerArray = new ArrayList<>();
        taskNamesArray = new ArrayList<>();
        taskDurationsArray = new ArrayList<>();

        // Populate with sample data
        developerArray.add("Alice");
        developerArray.add("Bob");
        developerArray.add("Charlie");

        taskNamesArray.add("Task1");
        taskNamesArray.add("Task2");
        taskNamesArray.add("Task3");

        taskDurationsArray.add(5);  // 5 hours
        taskDurationsArray.add(8);  // 8 hours
        taskDurationsArray.add(3);  // 3 hours
    }

    @Test
    public void testSearchTasksByDeveloper() {
        assertEquals(3, developerArray.size());
        assertTrue(developerArray.contains("Alice"));
    }

    @Test
    public void testValidTaskDescriptionLength() {
        for (String taskName : taskNamesArray) {
            assertTrue(taskName.length() > 0);  // Task name should not be empty
        }
    }

    @Test
    public void testTotalTaskDuration() {
        int totalDuration = taskDurationsArray.stream().mapToInt(Integer::intValue).sum();
        assertEquals(16, totalDuration);  // Expected: 5 + 8 + 3 = 16
    }

    @Test
    public void testDeveloperArrayPopulation() {
        assertNotNull(developerArray);
        assertEquals(3, developerArray.size());
        assertEquals("Charlie", developerArray.get(2));
    }

    @Test
    public void testLongestTaskDuration() {
        int maxDuration = taskDurationsArray.stream().mapToInt(Integer::intValue).max().orElse(0);
        assertEquals(8, maxDuration);  // Longest task duration is 8 hours
    }

    @Test
    public void testDeleteTask() {
        String taskToDelete = "Task2";
        int index = taskNamesArray.indexOf(taskToDelete);
        assertTrue(index >= 0);  // Ensure task exists before deleting

        taskNamesArray.remove(taskToDelete);
        assertFalse(taskNamesArray.contains(taskToDelete));  // Confirm deletion
    }

    @Test
    public void testSearchTaskByName() {
        String taskToFind = "Task1";
        int index = taskNamesArray.indexOf(taskToFind);
        assertTrue(index >= 0);  // Ensure task exists
        assertEquals(0, index);  // "Task1" is at index 0
    }

    @Test
    public void testDisplayAllTasks() {
        assertEquals(3, taskNamesArray.size());
        for (String task : taskNamesArray) {
            System.out.println(task);  // Display task names
        }
    }

    @Test
    public void testTaskIDGeneration() {
        String taskName = "Task1";
        int taskNumber = 1;
        String developer = "Alice";

        String generatedTaskID = Account.generateTaskID(taskName, taskNumber, developer);
        assertEquals("Task1:1:Alice", generatedTaskID);  // Example format
    }
}
